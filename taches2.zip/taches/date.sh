#!/bin/bash
# pour avoir les variables
heure=$(date +%H-%M)
jour=$(date +%Y%m%d) # date est une commande donc je change de nom
mysqldump -u root -pping236 --databases banque > $heure-$jour."sql"
sshpass -p mbayen12 scp  $heure-$jour."sql" mbaye@192.168.1.210:/home/mbaye/Bureau/sql

