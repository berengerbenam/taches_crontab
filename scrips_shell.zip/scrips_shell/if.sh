#!/bin/bash
##########premier script##########################################""
nom="berenger";

if [ "$nom" == "benam" ]
then
	echo "mon nom est benam";
else
	echo "mon nom n'est pas benam";
fi
