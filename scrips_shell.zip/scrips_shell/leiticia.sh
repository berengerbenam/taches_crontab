#!/bin/bash
nom="mervine";

if [ "$nom" == "leiticia" ]
then
	echo "mon nom est leiticia";
else
	echo "mon nom n'est pas leiticia";
fi
