#!/bin/bash
##########premier script##########################################""
echo "voici mon premier script "
nom="berenger"
age=12;
echo "mon nom est : $nom et j'ai $age ans"
############2eme script addition number###########################""""
a=5;
b=6;
result=$(($a+$b));
echo "le resultat est : $result";
#######################################FIN####################################################
a=15;
b=5;
result=$(($a*$b));
echo "la multiplication est : $result";

