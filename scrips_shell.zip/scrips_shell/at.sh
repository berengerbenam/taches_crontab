#!/bin/bash
echo "entrer votre prenom: "
read nom
echo "entrer votre nom  :"
read prenom

sed -i s/prenom/$nom/g name.txt
sed -i s/nom/$prenom/g name.txt

echo "modification avec succés" 

