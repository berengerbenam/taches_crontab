#!/bin/bash

echo "---------------------------Mises a jour du systéme d'exploitation--------------------------------------------------------------------"
sudo apt-get update
sleep  7

sudo apt-get update
sleep 10

echo "--------------------------------------------Mises a jour terminé--------------------------------------------------------------------"

