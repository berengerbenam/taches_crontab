#!/bin/bash

echo "----------------------------------------------------------Crétation du dossier tp_f-----------------------------------------------"
mkdir tp_f
sleep 10

echo "----------------------------------------------------------se déplacer dans le dossier tp_f--------------------------------------"
cd tp_f
sleep 5

echo "----------------------------------------------------------Crétation du fichier benam.txt--------------------------------------------"
touch benam.txt
sleep 11

echo "----------------------------------------------------------Copier le fichier if.sh dans benam.txt--------------------------------"

cp /home/berenger/if.sh /home/berenger/scrips_shell/tp_f/benam.txt

echo "------------------------------------------------------------------Fin du script bye-bye------------------------------------------"

