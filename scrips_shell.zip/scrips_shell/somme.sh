#!/bin/bash
echo "la somme de deux nombres entiers : ";
a=5;
b=10;
somme=$(($a+$b));
echo "la somme de a + b est : $somme";

