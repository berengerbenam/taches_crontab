#!/bin/bash
cd Bureau/
touch text.txt
echo "nom : Benam et Prenom : Berenger">text.txt
