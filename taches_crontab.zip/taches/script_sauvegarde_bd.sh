#!/bin/bash
gnome-terminal
cd /home/benam/Bureau
gnome-terminal --maximize --tab -e 'bash -c "mysqldump -u root -p --databases banque >banque.sql;$SHELL"'
 

