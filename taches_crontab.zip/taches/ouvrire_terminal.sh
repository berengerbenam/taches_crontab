#!/bin/bash
gnome-terminal --maximize --tab -e 'bash -c "./at.sh;$SHELL"'
#gnome-terminal --maximize --tab -e 'bash -c "cat name.txt;$SHELL"'
echo "vous applez : "
